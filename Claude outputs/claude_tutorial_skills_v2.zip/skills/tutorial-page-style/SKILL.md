---
name: "tutorial-page-style"
description: "Use when writing or revising pages for the user's student tutorial sites (Zensical/Markdown): their inclusive 'we' voice, page templates, PRIMM callouts, line-by-line code explanations and question-style exercises."
---

# Tutorial page style

The house style for the user's tutorial sites, set during the *Python meets micro:bit* rework. Use it for new pages and when checking a migrated site for consistency.

## First: ask for the year level

The user's sites are written for different year levels (for example Year 7/8 or Year 9/10). Before writing or revising any page, ask which year level the site is for, using AskUserQuestion with options such as Year 7/8, Year 9/10 and Other. Don't assume it from another site. Once answered, use that level for the whole site, and record it in the Context section of the site's `VSCODE_CLAUDE_TASKS.md`.

Adjust to the year level:

| Aspect | Year 7/8 | Year 9/10 |
| --- | --- | --- |
| Sentences | short and plain | can be longer; still clear |
| Technical terms | bold and define every new term | bold and define new terms; use standard terms (function, parameter, return value, object) freely once introduced |
| Code explanations | every line explained | every line explained; can group simple lines (`lines 1–2`) and say why as well as what |
| Examples | the method used once, minimal supporting code | same rule; can use functions and data structures students have met |
| Exercises | one clear change or small program; multi-part tasks listed | more open design; can include planning, testing and justifying choices |
| Real-world links | everyday, familiar contexts | can include industry and data contexts |

If the level is something else (for example Year 11/12 Digital Solutions), ask what should change from the Year 9/10 column.

## Voice

- Australian English (colour, organise, centre, program for software).
- An inclusive "we" voice in instructions and explanations: "we need to", "our program", "Let's". Explanations of what code does are in the third person ("imports…", "shows…").
- Bold new terms the first time they're used (**tuple**, **Unix time**).
- No step-by-step click instructions on content pages. General how-to (creating a program, uploading files) lives once in the introductory section, and content pages link to it.
- Before rewriting, read several pages of the user's original site to match their voice, and keep their phrasings where they work.

The user checks new pages for their voice. Their writing has these markers, so use them in new prose:

- plain, practical sentences with linking words: "So …", "Now that we have …, let's …", "Right now …", "Let's think about this:"
- "figure out" and "work out" rather than formal verbs ("determine", "identify")
- a link back to what students have already done ("Just like in Stage 2 …", "Remember from the OOP Primer …"), and why the next step is needed ("That was a good start, but it's not much of a game yet.")
- arrow chains for reasoning and mappings: `- the backpack describes part of the player → attribute`
- the same instruction pattern every time: "Create a new file, add the code below and save it as ***x.py***", "Go back to ***x.py*** and add the highlighted code below", "Return to ***main.py*** and change the highlighted code"
- numbered reasoning when working through a problem ("So let's think about this: 1. … 2. …")

Avoid punchy or aphoristic lines ("This is a job for …", "changing a diagram takes seconds") and marketing-style phrasing.

## Callouts

Every site uses exactly five callout types. Their colours and icons are the same on every site (set in `extra.css`; see the `sphinx-to-zensical-migration` skill). Each icon is chosen to match what the callout holds:

| Type | Syntax | Use | Colour | Icon |
| --- | --- | --- | --- | --- |
| Learning intentions | `!!! learn "In this lesson we will learn"` (lessons) or `!!! learn "On this page we will learn"` (reference and guide pages) | a bullet list of what the page teaches, at the top of every content page | amber | target (goals) |
| PRIMM | `!!! primm "PRIMM"` | the Predict/Run/Investigate steps after every example, and Modify prompts | green | flask (an experiment: predict, run, test) |
| Code explanation | `??? note "Code explanation"` | the collapsed line-by-line explanation after every example's PRIMM callout | purple | code brackets `</>` |
| Tip | `!!! tip "Title"` | every other aside: background information, definitions, comparisons and hints (for example "Tuples", "How radio works", "Naming rules") | light blue | light bulb |
| Warning | `!!! warning "Title"` | things that break or catch students out (for example "New program, new folder") | hot pink | triangle alert |

- `note` is reserved for Code explanation boxes. Never use an open `!!! note` for asides; use `tip` instead. The only open `!!! note` is the Code explanation example on the home page (see below).
- Every content page starts with one `learn` callout, directly under the `# Title` and **above** the video (and above any "There is no video for this lesson." line). Each bullet starts with a lower-case word ("how to…", "what…", "why…") and has no full stop. Keep to three to five bullets that match the page's sections. Skip it on the home, licence, solutions and other index pages.
- Don't use any other callout types (`info`, `danger`, `example` and so on).
- Give every tip and warning a short title that says what it's about.

```markdown
# Lesson 10: While Loops

!!! learn "In this lesson we will learn"
    - the difference between definite and indefinite iteration
    - how to use comparison operators
    - how to use a `while` loop to repeat until something happens

<iframe ... src="https://www.youtube-nocookie.com/embed/<id>" ...></iframe>
```

PRIMM uses a custom admonition type `primm`:

```markdown
!!! primm "PRIMM"
    1. **Predict** what you think will happen. Be specific.
    2. **Run** the program.
    3. Time to **investigate** the code. What does each line do?
```

The first time a site introduces PRIMM, explain the five steps in normal page text (a list), then use the standard `primm` callout. Don't put the introduction inside a `tip` or `note`.

## Code blocks

- Show example code through snippets in a numbered fence (```` ```python linenums="1" ````). Every code block gets a thin grey border from `extra.css`.
- Show Shell output in a plain ```` ```text ```` block.
- Show error messages in an error block, which has a red border and red text:

    ````markdown
    ``` { .text .error linenums="1" }
    Traceback (most recent call last):
      File "<string>", line 3, in <module>
    NameError: name 'prnt' is not defined
    ```
    ````

    Then break the error down line by line in a list underneath.

## Code explanations

Put these after every example's PRIMM callout, collapsed:

```markdown
??? note "Code explanation"
    - **line 1** → imports all the commands from the `microbit` library.
    - **lines 6–11** → sets the year, month, day, hour, minute and second properties.
    - **line 7** → if it isn't…
    - **line 8** → …shows a sad face.
```

- Explain every non-blank, non-comment line, and never refer to blank or comment lines. `scripts/check_explanations.py` enforces this.
- Each explanation is a full sentence starting with a lower-case verb and ending in a full stop. Use an en dash for line ranges.
- Use `…` to join an `if` and its `else` across lines.
- On project-build sites, where each step shows the whole file, explain only the highlighted (new or changed) lines.
- When one step changes two files, put a Code explanation box straight after each file's snippet. PRIMM goes once, after the file students run (usually ***main.py***), because `check_explanations.py` pairs each box with the snippet directly above it.
- For non-Python blocks (a Modelfile, a terminal command), use backticked keywords instead of line numbers: `` - `FROM` → sets the base model. ``

## Home page

The home page (`index.md`) has no `learn` callout. It has, in order: a one-line description of the site, `## How to use this site`, `## How each page works` (on reference-style sites), then the three sections below, then `## Tutorial files`.

Before writing these sections, search the site's pages for what they actually use (`{ .text .error`, `hl_lines`, ```` ```text ````) and explain only the features that appear. Name the editor students use (for example Thonny or Pybricks), and say "lesson pages" on sequential sites and "tutorial pages" on reference sites.

### 1. `## Callouts` (every site)

One sentence introducing callouts, then one example of each of the five types, each explaining itself inside its own callout. Make the Code explanation example an open `!!! note` so it can be read without clicking:

```markdown
## Callouts

Coloured boxes called **callouts** highlight different kinds of information. Each type of callout has its own colour and icon, so we can tell at a glance what it's for.

!!! learn "Learning intentions"
    This callout is at the top of every tutorial page. It lists what we will learn on that page.

!!! primm "PRIMM"
    This callout comes after each example program. It asks us to **predict** what the code will do, **run** it, and **investigate** how it works. Sometimes it asks us to **modify** the code.

!!! note "Code explanation"
    This callout comes after each PRIMM callout and gives a line-by-line explanation of the example program. On the tutorial pages it starts closed, so we can make our own prediction first. Click its title to open it.

!!! tip "Tip"
    This callout gives extra information, such as definitions, background facts, comparisons and hints.

!!! warning "Warning"
    This callout warns us about mistakes that are easy to make, or things that will stop our program working.
```

Adapt the warning's last words to the site ("our program or robot", "our program or micro:bit").

### 2. `## Code blocks` (every site)

A short example program in a numbered fence, then bullets for the features the site uses:

- **line numbers**, which match the Code explanation (and error messages, if the site has them)
- **highlighted lines**, which show lines that are new or changed since the last version (only if the site uses `hl_lines` that way as a regular pattern, not for a one-off)
- the **copy** button in the top-right corner, which copies the code to paste into the editor

If the site shows Shell output in plain ```` ```text ```` blocks, add: "Code blocks without colours show what appears in the **Shell** when we run a program."

### 3. `## Error messages` (only if the site has error blocks)

"Error messages are shown in red code blocks like this one:", an example error block, then: "Under each error message, the lesson breaks it down line by line, so we learn how to read the error and fix our code."

## Page templates

Ask which template fits when a page doesn't clearly match one. On mixed sites, use each template where it fits.

### A. Component / library reference page

1. `# Title`
2. `!!! learn "On this page we will learn"` with the page's learning intentions
3. YouTube video iframe (`youtube-nocookie.com/embed/<id>`), if there is one
4. one sentence saying what it does
5. `Possible uses:` followed by a bullet list
6. `## Connect it`: wiring, files to upload, key facts (coordinates, ranges, units). For built-in parts, say we don't need to connect anything and link to the first-program page.
7. `## Set it up`: the import and object creation in a code block
8. `## Methods`: a table with the columns `Method | Parameters | Returns | Description`, plus a property table where the library uses properties
9. for each method, a `### \`method()\`` section with a short explanation sentence, the example, PRIMM and the code explanation
10. `## Documentation`: the standard sentence, then links
11. `## Exercises`

The standard Documentation sentence:

> Documentation is the official guide written by the people who made the code library, and we can use it to look up every method and its parameters, including ones that aren't covered on this page.

### B. Sequential lesson page

1. `# Title`
2. `!!! learn "In this lesson we will learn"` with the lesson's learning intentions
3. the video and its `[Video link](...)` line if there is one, otherwise "There is no video for this lesson."
4. concept sections, each with a short explanation, an example, PRIMM and a code explanation
5. a `tip` or `warning` for common mistakes
6. `## Exercises`

### B2. Project-build stage page

For sites that build one program across the pages (for example *Deepest Dungeon*): the `learn` callout, the video, `## Introduction`, then `### Pseudocode` (a ```` ```text title="Stage N pseudocode" ```` block) and `### Class diagram`, then the build steps and testing tables. Finish with `## Exercises` holding one open **make** task on the student's own version of the program, phrased as a question, with no starter or solution. Mention the file name in the first comment line of every file (`# room.py`), and explain this on the home page.

### C. Project / challenge page

1. `# Title`, then `!!! learn "On this page we will learn"`, then a video if there is one, then one sentence describing the challenge
2. `## What you need`: hardware, files and prior pages
3. `## Plan`: an input → process → output table
4. `## Build it`: a worked example in steps, each with the code so far, explained
5. `## Test it`: what to check and the expected results
6. `## Extend it`: "Can you …?" challenges

### D. Guide / reference page

For setup, debugging, components and similar guide pages: a `learn` callout under the title (above any video), then short sections with a numbered list for procedures (step, why, expected result) and screenshots where the user supplies them. Licence pages have no `learn` callout.

### E. Developing a new program guide

For a guide that teaches students to plan and build their own program (first used on *Deepest Dungeon*, with a pet shelter example): the `learn` callout, a short intro linking back to how the site's stages were planned, then four numbered sections:

1. `## 1. Define the problem`: requirements as a table with IDs (R1, R2 …), plus a tip on writing testable requirements
2. `## 2. Design the solution`: nouns → classes and verbs → methods as arrow lists, a class table (Class | Attributes | Methods) standing in for the UML diagram, and pseudocode for the build order
3. `## 3. Build in small stages`: one stepped snippet per step with Code explanations, and PRIMM after each runnable step
4. `## 4. Test and evaluate`: a testing table covering every branch, then an evaluation table (ID | Requirement | Met? | Evidence) and possible improvements

Finish with `## Your turn`: a numbered checklist for the student's own program and a tip with project ideas. Use a small worked example in a different domain from the site's main project, so students see the process transfer, and refer to the requirement IDs as each step meets them.

## Exercises section

```markdown
## Exercises

!!! primm "PRIMM"
    Time to **modify** the code and see what happens.

Starter files are in the `<page>` folder of your tutorial files. Solutions are on the [Exercise Solutions](../reference/solutions.md#<anchor>) page.

### Exercise 1

Starter: `<page>/ex1_name`

Can you …? For example:

![alt](../assets/<gif>)
```

- Phrase every exercise as a question ("Can you …?"). Explain-why exercises ask "What happens if …? Why do you think this happens?"
- Use "For example:" before a GIF or image showing the target result.
- Put multi-part tasks in a bullet list after "It should:".
- Don't use `- [ ]` checkboxes: the sites don't enable `pymdownx.tasklist`, so they render as literal brackets. Use a numbered list for checklists.
- Keep exercises relevant to students' lives at their year level. For example, the Year 7/8 micro:bit RTC exercise uses a day greeting, not Unix time.
- For a two-device exercise, say `(both micro:bits)` or list both starters.

## Solutions page

`reference/solutions.md` has one `##` section per page and one `### Exercise N` per exercise. It includes `solutions/.../exN_name.py` through snippets, with no explanation boxes. Explain-why exercises get a short prose answer instead of code. Open the page by saying these are **a** solution, and any program that produces the required result solves the problem.

## Before handing over

- `python scripts/check_explanations.py` gives `0 issue(s) found`.
- `zensical build --clean` gives `No issues found`.
- Check across pages for the "we" voice, PRIMM after every example, question-style exercises, Australian spelling and language suited to the site's year level.
- Check that no content page has an open `!!! note` (`note` is only for Code explanation boxes), that only the five callout types are used, and that every content page starts with a `learn` callout directly under the title, above any video.
- Check the home page has the Callouts and Code blocks sections, an Error messages section only if the site uses error blocks, and that it explains only features the site actually uses.