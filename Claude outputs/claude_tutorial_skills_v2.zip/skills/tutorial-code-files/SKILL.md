---
name: "tutorial-code-files"
description: "Use when creating or revising example, exercise-starter and solution code for the user's tutorial sites, including the minimal-example rules, Setup/Main loop structure, starter instruction comments, the student zip and the explanation checker."
---

# Tutorial code files

Conventions for the code in the user's Zensical tutorial sites, set during the *Python meets micro:bit* rework. Adapt the language details (MicroPython, Python, PyQt and so on) to the site, and ask when the structure doesn't obviously carry over.

## Layout

```
docs/examples/<group>/<page>/<example>/main.py     # one folder per example
docs/examples/<group>/<page>/exN_name/main.py      # exercise starters
docs/solutions/<group>/<page>/exN_name.py          # solutions
docs/drivers/                                      # one copy of each third-party file
docs/downloads/<site>_tutorials.zip                # built by scripts/make_zip.py
```

- `<group>` is the nav section (for example `microbit`, `piicodev`, `other`). Intro-section pages can sit one level higher (`examples/<section>/<example>`).
- Name example folders after the method (`get_x`, `setDateTime`). Name exercise folders `exN_short_name`.
- Pages include examples with snippets inside a numbered fence:

  ````markdown
  ```python linenums="1"
  --8<-- "examples/microbit/buttons/is_pressed/main.py"
  ```
  ````

### Project-build sites (one program built across pages)

Some sites (for example *Deepest Dungeon*) build one multi-file program across the whole site rather than showing small separate examples. Each page shows the full file after every change. For these:

```
docs/examples/<section>/stepNN/<file>.py    # only the files that changed in that step
docs/examples/<section>/stepNNb/<file>.py   # a step inserted later, sorts between NN and NN+1
```

- Include the **whole file** with `hl_lines` marking the new or changed lines:

  ````markdown
  ```python linenums="1" hl_lines="15-19"
  --8<-- "examples/stage_1/step09/main.py"
  ```
  ````

- To show part of a file, use a line range and start the numbering to match. `hl_lines` still counts from 1 within the block:

  ````markdown
  ```python linenums="65" hl_lines="4 7"
  --8<-- "examples/stage_4/step06/main.py:65:73"
  ```
  ````

- Never type a fragment by hand. Make it a line range of a real step file, so it can't drift from the full program.
- Build each step file from the previous version with a script (search and replace with a check that each change matches exactly once), then diff the steps to confirm the highlighted lines are the only changes.
- Minimal-example rules and exercise starters don't apply: the code is the student's growing program, kept as the user wrote it apart from bug fixes.

## Example rules

- Each example uses its method **once**, with only the supporting code needed to see it work.
- Keep the program structure even when it's tiny: imports, a blank line, `# Setup` (left out when empty), `# Main loop`, then `while True:`. Keep the loop, because students copy the pattern.
- Comments are structural only (`# Setup`, `# Main loop`, and `# Input` / `# Process` / `# Output` in larger programs). Explanations belong in the page's Code explanation box, not in comments.
- Print to the Shell when the result isn't visible on the device.
- Check the API against the library's source or README before writing. List any unverified assumptions in the VS Code handoff file for testing.
- If an example changes, update its line-number explanation, then run the checker.

The micro:bit template:

```python
from microbit import *

# Setup

# Main loop
while True:
    pass
```

## Exercise starters

- A starter is either the skeleton above (with the page's imports and device setup) or a copy of the example the exercise modifies.
- Every starter begins with an instruction comment block copied from the page's Exercises section, with markdown bold, backticks, links and images removed, wrapped at about 76 characters:

  ```python
  # Exercise 3
  # Can you create a program that tests the player's reaction time? It should:
  # - randomly choose which button to press: A or B
  # - count down 3-2-1, then show the button to press
  #
  ```

  For two-device exercises, add a line such as `# This file is for the inside micro:bit.`
- If an exercise's wording changes on the page, update the starter comment to match. Generate the comments with a script that parses each page's `### Exercise N` / `Starter:` blocks, rather than typing them by hand.

## Solutions

- Write a real, working solution for every coding exercise. Don't copy the starter.
- Use the same structure as the examples, but no instruction comment, because the solutions page shows the file in full.
- Flag solutions that need hardware testing or a judgement call (thresholds, calibration, song choice) under the user's tasks in the handoff file.

## Scripts

### scripts/make_zip.py

Builds the student download from `docs/examples`:

- For each `main.py`, write it to `<site>_tutorials/<page>/<example>/main.py`, taking `<page>/<example>` from `parts[-2:]` of the path relative to `docs/examples` (this handles both depths).
- A `PAGE_DRIVERS` dict maps each page to the driver files copied into every example folder of that page, from `docs/drivers/`.
- Print a `WARNING` for each missing driver.
- Rebuild the zip after any change to examples or starters.

A stepped example inside a guide (for example `guides/pet_shelter/stepNN/`) is written to the zip as one finished folder, using the latest version of each file. Single-file guide examples (`guides/buggy_code/main.py`) are written as `guides/<name>.py`.

On project-build sites, the zip holds **checkpoints**: for each section, the latest version of every file, carried forward from earlier sections, written to `<site>/<section>/<file>.py`. Each folder is then a complete, runnable program students can restart from. Extensions that branch from the end of the main sequence start from its final files. Test every checkpoint by piping a list of commands to its `main.py` (stub any external library) and checking it reaches the expected ending.

### scripts/check_explanations.py

For every `--8<-- "path"` followed by a `??? note "Code explanation"` box, parse the `line n` / `lines n–m` references and report:

- `BAD`: a reference to a blank line, a comment or a line past the end
- `MISSING`: a code line with no explanation

End with `N issue(s) found`, and exit with 1 when there are issues. Run it after every example edit. The target is `0 issue(s) found`.

The project-build version (from *Deepest Dungeon*) also:

- reads the fence header above each snippet for `linenums="N"` and `hl_lines`, and handles `path:start:end` ranges, so references use the line numbers shown on the page
- only requires explanations for **highlighted** code lines when the fence has `hl_lines`, because the other lines were explained when they first appeared

Copy it from the Deepest Dungeon repo (`scripts/check_explanations.py`) for any site with stepped programs.

## Memory and upload notes (micro:bit)

The micro:bit has limited memory. Tell students to upload only the drivers the current program needs, and to remove unused driver files from the device. Every program needs its own folder containing its own `main.py`.