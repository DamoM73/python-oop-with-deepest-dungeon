# room.py

class Room():
